(function() {
  'use strict';

  const elements = {
    autoCvcToggle: document.getElementById('autoCvcToggle'),
    autoScreenshotToggle: document.getElementById('autoScreenshotToggle'),
    // autoCaptchaToggle: document.getElementById('autoCaptchaToggle'),
    captchaService: document.getElementById('captchaService'),
    captchaApiKey: document.getElementById('captchaApiKey'),
    autofillToggle: document.getElementById('autofillToggle'),
    autofillCardDataToggle: document.getElementById('autofillCardDataToggle'),
    autofillBillingDataToggle: document.getElementById('autofillBillingDataToggle'),
    autofillDelay: document.getElementById('autofillDelay'),
    customCardNumber: document.getElementById('customCardNumber'),
    customCardExpiry: document.getElementById('customCardExpiry'),
    customCardCvc: document.getElementById('customCardCvc'),
    customName: document.getElementById('customName'),
    customAddress1: document.getElementById('customAddress1'),
    customAddress2: document.getElementById('customAddress2'),
    customLocality: document.getElementById('customLocality'),
    useRandomNames: document.getElementById('useRandomNames'),
    useRandomAddresses: document.getElementById('useRandomAddresses'),
    saveAutofillSettingsBtn: document.getElementById('saveAutofillSettingsBtn'),
    resetAutofillSettingsBtn: document.getElementById('resetAutofillSettingsBtn'),
    hardwareAcceleration: document.getElementById('hardwareAcceleration'),
    reduceAnimations: document.getElementById('reduceAnimations'),
    themeColorPicker: document.getElementById('themeColorPicker'),
    resetThemeColor: document.getElementById('resetThemeColor'),
    telegramEnabled: document.getElementById('telegramEnabled'),
    telegramBotToken: document.getElementById('telegramBotToken'),
    telegramChatId: document.getElementById('telegramChatId'),
    testTelegramConnection: document.getElementById('testTelegramConnection'),
    autoClickButtons: document.getElementById('autoClickButtons'),
    autoClickDelay: document.getElementById('autoClickDelay'),
    saveSettingsBtn: document.getElementById('saveSettingsBtn'),
    buildDate: document.getElementById('buildDate'),
    notification: document.getElementById('notification')
  };

  // Default settings
  const defaultSettings = {
    autoCvc: true,
    autoScreenshot: true,
    autoCaptcha: false,
    captchaService: 'autoclick',
    captchaApiKey: '',
    autofill: true,
    autofillCardData: true,
    autofillBillingData: true,
    autofillDelay: 7,
    customCardNumber: '',
    customCardExpiry: '',
    customCardCvc: '',
    customName: '',
    customAddress1: '',
    customAddress2: '',
    customLocality: '',
    useRandomNames: false,
    useRandomAddresses: false,
    hardwareAcceleration: true,
    reduceAnimations: false,
    themeColor: '#4a9eff',
    telegramEnabled: false,
    telegramBotToken: '',
    telegramChatId: '',
    autoClickButtons: true,
    autoClickDelay: 2000
  };
  
  // Function to apply theme color
  function applyThemeColor(color) {
    if (!color) return;
    
    // Convert hex to RGB
    const hex = color.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    
    // Calculate lighter shade for secondary color
    const lighterR = Math.min(255, r + 30);
    const lighterG = Math.min(255, g + 30);
    const lighterB = Math.min(255, b + 30);
    const secondaryColor = `rgb(${lighterR}, ${lighterG}, ${lighterB})`;
    
    // Calculate accent color (shift hue slightly)
    const accentR = Math.min(255, Math.max(0, r - 20));
    const accentG = Math.min(255, Math.max(0, g - 10));
    const accentB = Math.min(255, b + 30);
    const accentColor = `rgb(${accentR}, ${accentG}, ${accentB})`;
    
    // Apply CSS variables
    document.documentElement.style.setProperty('--theme-primary', color);
    document.documentElement.style.setProperty('--theme-secondary', secondaryColor);
    document.documentElement.style.setProperty('--theme-accent', accentColor);
    document.documentElement.style.setProperty('--theme-primary-rgb', `${r}, ${g}, ${b}`);
    document.documentElement.style.setProperty('--theme-accent-rgb', `${accentR}, ${accentG}, ${accentB}`);
    
    // Update background gradients dynamically
    updateBackgroundGradients(color, r, g, b, accentR, accentG, accentB);
    
    // Also update the background iframe if it exists
    const iframe = document.getElementById('backgroundIframe');
    if (iframe && iframe.contentDocument) {
      try {
        iframe.contentDocument.documentElement.style.setProperty('--theme-primary', color);
        iframe.contentDocument.documentElement.style.setProperty('--theme-secondary', secondaryColor);
        iframe.contentDocument.documentElement.style.setProperty('--theme-accent', accentColor);
        iframe.contentDocument.documentElement.style.setProperty('--theme-primary-rgb', `${r}, ${g}, ${b}`);
        iframe.contentDocument.documentElement.style.setProperty('--theme-accent-rgb', `${accentR}, ${accentG}, ${accentB}`);
        
        // Update iframe background via postMessage
        iframe.contentWindow.postMessage({
          type: 'UPDATE_THEME',
          themeColor: color,
          themePrimaryRgb: `${r}, ${g}, ${b}`,
          themeAccentRgb: `${accentR}, ${accentG}, ${accentB}`
        }, '*');
      } catch (e) {
        // Cross-origin, ignore
      }
    }
  }
  
  // Function to update background gradients
  function updateBackgroundGradients(color, r, g, b, accentR, accentG, accentB) {
    // Update via dynamic style element
    let styleEl = document.getElementById('dynamic-theme-styles');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'dynamic-theme-styles';
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = `
      body {
        background: 
          linear-gradient(135deg, rgba(${r}, ${g}, ${b}, 0.12) 0%, rgba(${accentR}, ${accentG}, ${accentB}, 0.12) 100%),
          #0a0a0f !important;
      }
      body::before {
        background: 
          radial-gradient(circle at 0% 0%, rgba(${r}, ${g}, ${b}, 0.25) 0%, transparent 70%),
          radial-gradient(circle at 100% 100%, rgba(${accentR}, ${accentG}, ${accentB}, 0.25) 0%, transparent 70%),
          radial-gradient(circle at 50% 50%, rgba(${r}, ${g}, ${b}, 0.15) 0%, transparent 80%) !important;
      }
      body::after {
        background: 
          radial-gradient(circle at 0% 0%, rgba(${r}, ${g}, ${b}, 0.18) 0%, transparent 75%),
          radial-gradient(circle at 100% 100%, rgba(${accentR}, ${accentG}, ${accentB}, 0.18) 0%, transparent 75%) !important;
      }
      .overlay {
        background: rgba(0, 0, 0, 0.4) !important;
      }
      .background-iframe {
        filter: hue-rotate(${Math.round((r + g + b) / 3 / 255 * 60)}deg) saturate(1.4) brightness(0.85) !important;
        -webkit-filter: hue-rotate(${Math.round((r + g + b) / 3 / 255 * 60)}deg) saturate(1.4) brightness(0.85) !important;
      }
    `;
  }

  // Load settings from storage - optimized with requestAnimationFrame
  function loadSettings() {
    requestAnimationFrame(() => {
      chrome.storage.local.get(['bypasserSettings', 'bypasserAdvancedSettings'], (result) => {
      const settings = result.bypasserSettings || {};
      const advancedSettings = result.bypasserAdvancedSettings || {};
      
      // Update cache
      settingsCache.bypasserSettings = settings;
      settingsCache.bypasserAdvancedSettings = advancedSettings;
      
      // Load general settings (from bypasserSettings)
      if (elements.autoCvcToggle) {
        elements.autoCvcToggle.checked = settings.autoCvc !== undefined 
          ? settings.autoCvc 
          : defaultSettings.autoCvc;
      }
      if (elements.autoScreenshotToggle) {
        elements.autoScreenshotToggle.checked = settings.autoScreenshot !== undefined 
          ? settings.autoScreenshot 
          : defaultSettings.autoScreenshot;
      }
      
      // Load captcha settings (from bypasserAdvancedSettings)
      // elements.autoCaptchaToggle.checked = advancedSettings.autoCaptcha !== undefined 
      //   ? advancedSettings.autoCaptcha 
      //   : defaultSettings.autoCaptcha;
      if (elements.captchaService) {
        elements.captchaService.value = advancedSettings.captchaService || defaultSettings.captchaService;
      }
      if (elements.captchaApiKey) {
        elements.captchaApiKey.value = advancedSettings.captchaApiKey || defaultSettings.captchaApiKey;
      }
      
      // Load autofill settings (from bypasserAdvancedSettings)
      if (elements.autofillToggle) {
        elements.autofillToggle.checked = advancedSettings.autofill !== undefined 
          ? advancedSettings.autofill 
          : defaultSettings.autofill;
      }
      if (elements.autofillCardDataToggle) {
        elements.autofillCardDataToggle.checked = advancedSettings.autofillCardData !== undefined 
          ? advancedSettings.autofillCardData 
          : defaultSettings.autofillCardData;
      }
      if (elements.autofillBillingDataToggle) {
        elements.autofillBillingDataToggle.checked = advancedSettings.autofillBillingData !== undefined 
          ? advancedSettings.autofillBillingData 
          : defaultSettings.autofillBillingData;
      }
      
      // Load custom autofill data
      if (elements.autofillDelay) {
        elements.autofillDelay.value = advancedSettings.autofillDelay !== undefined 
          ? advancedSettings.autofillDelay 
          : defaultSettings.autofillDelay;
      }
      if (elements.customCardNumber) {
        elements.customCardNumber.value = advancedSettings.customCardNumber || defaultSettings.customCardNumber;
      }
      if (elements.customCardExpiry) {
        elements.customCardExpiry.value = advancedSettings.customCardExpiry || defaultSettings.customCardExpiry;
      }
      if (elements.customCardCvc) {
        elements.customCardCvc.value = advancedSettings.customCardCvc || defaultSettings.customCardCvc;
      }
      if (elements.customName) {
        elements.customName.value = advancedSettings.customName || defaultSettings.customName;
      }
      if (elements.customAddress1) {
        elements.customAddress1.value = advancedSettings.customAddress1 || defaultSettings.customAddress1;
      }
      if (elements.customAddress2) {
        elements.customAddress2.value = advancedSettings.customAddress2 || defaultSettings.customAddress2;
      }
      if (elements.customLocality) {
        elements.customLocality.value = advancedSettings.customLocality || defaultSettings.customLocality;
      }
      if (elements.useRandomNames) {
        elements.useRandomNames.checked = advancedSettings.useRandomNames !== undefined 
          ? advancedSettings.useRandomNames 
          : defaultSettings.useRandomNames;
      }
      if (elements.useRandomAddresses) {
        elements.useRandomAddresses.checked = advancedSettings.useRandomAddresses !== undefined 
          ? advancedSettings.useRandomAddresses 
          : defaultSettings.useRandomAddresses;
      }
      
      // Load Telegram settings
      if (elements.telegramEnabled) {
        elements.telegramEnabled.checked = advancedSettings.telegramEnabled !== undefined 
          ? advancedSettings.telegramEnabled 
          : defaultSettings.telegramEnabled;
      }
      if (elements.telegramBotToken) {
        elements.telegramBotToken.value = advancedSettings.telegramBotToken || defaultSettings.telegramBotToken;
      }
      if (elements.telegramChatId) {
        elements.telegramChatId.value = advancedSettings.telegramChatId || defaultSettings.telegramChatId;
      }
      
      // Load auto-clicker settings
      if (elements.autoClickButtons) {
        elements.autoClickButtons.checked = advancedSettings.autoClickButtons !== undefined 
          ? advancedSettings.autoClickButtons 
          : defaultSettings.autoClickButtons;
      }
      if (elements.autoClickDelay) {
        elements.autoClickDelay.value = advancedSettings.autoClickDelay || defaultSettings.autoClickDelay;
      }
      
      // Show/hide API key field based on service
      updateApiKeyFieldVisibility();
      
      // Load performance settings
      if (elements.hardwareAcceleration) {
        elements.hardwareAcceleration.checked = advancedSettings.hardwareAcceleration !== undefined 
          ? advancedSettings.hardwareAcceleration 
          : defaultSettings.hardwareAcceleration;
      }
      if (elements.reduceAnimations) {
        elements.reduceAnimations.checked = advancedSettings.reduceAnimations !== undefined 
          ? advancedSettings.reduceAnimations 
          : defaultSettings.reduceAnimations;
      }
      
      // Load theme color
      const themeColor = advancedSettings.themeColor || defaultSettings.themeColor;
      if (elements.themeColorPicker) {
        elements.themeColorPicker.value = themeColor;
        applyThemeColor(themeColor);
      }
      
      // Update preset button states
      document.querySelectorAll('.theme-preset-btn').forEach(btn => {
        if (btn.dataset.color === themeColor) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
      
      // Set build date
      if (elements.buildDate) {
        elements.buildDate.textContent = new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      }
      });
    });
  }

  // In-memory settings cache for instant UI updates
  let settingsCache = {
    bypasserSettings: {},
    bypasserAdvancedSettings: {},
  };
  
  // Track if save is pending to prevent duplicate operations
  let savePending = false;
  let saveTimeout = null;
  
  // Debounced save function for better performance with requestAnimationFrame
  let saveRaf = null;
  function debouncedSaveSettings(immediate = false) {
    if (saveTimeout) {
      clearTimeout(saveTimeout);
    }
    if (saveRaf) {
      cancelAnimationFrame(saveRaf);
    }
    
    if (immediate) {
      saveRaf = requestAnimationFrame(() => {
        performSaveSettings();
      });
    } else {
      // Debounce saves - batch rapid changes
      saveTimeout = setTimeout(() => {
        saveRaf = requestAnimationFrame(() => {
          performSaveSettings();
        });
      }, 200); // Reduced delay for better responsiveness
    }
  }
  
  // Actual save function (called after debounce or immediately)
  function performSaveSettings() {
    if (savePending) {
      return; // Save already in progress
    }
    savePending = true;
    
    // Build settings from current UI state (use cache defaults)
    const updatedSettings = {
      ...settingsCache.bypasserSettings,
      autoCvc: elements.autoCvcToggle ? elements.autoCvcToggle.checked : (settingsCache.bypasserSettings.autoCvc !== undefined ? settingsCache.bypasserSettings.autoCvc : defaultSettings.autoCvc),
      autoScreenshot: elements.autoScreenshotToggle ? elements.autoScreenshotToggle.checked : (settingsCache.bypasserSettings.autoScreenshot !== undefined ? settingsCache.bypasserSettings.autoScreenshot : defaultSettings.autoScreenshot),
      lastUpdated: Date.now()
    };
    
    const advancedSettings = {
      ...settingsCache.bypasserAdvancedSettings,
      // autoCaptcha: elements.autoCaptchaToggle.checked,
      captchaService: elements.captchaService ? elements.captchaService.value : (settingsCache.bypasserAdvancedSettings.captchaService || defaultSettings.captchaService),
      captchaApiKey: elements.captchaApiKey ? elements.captchaApiKey.value.trim() : (settingsCache.bypasserAdvancedSettings.captchaApiKey || defaultSettings.captchaApiKey),
      autofill: elements.autofillToggle ? elements.autofillToggle.checked : defaultSettings.autofill,
      autofillCardData: elements.autofillCardDataToggle ? elements.autofillCardDataToggle.checked : defaultSettings.autofillCardData,
      autofillBillingData: elements.autofillBillingDataToggle ? elements.autofillBillingDataToggle.checked : defaultSettings.autofillBillingData,
      autofillDelay: elements.autofillDelay ? parseInt(elements.autofillDelay.value) || 7 : 7,
      customCardNumber: elements.customCardNumber ? elements.customCardNumber.value.trim() : '',
      customCardExpiry: elements.customCardExpiry ? elements.customCardExpiry.value.trim() : '',
      customCardCvc: elements.customCardCvc ? elements.customCardCvc.value.trim() : '',
      customName: elements.customName ? elements.customName.value.trim() : '',
      customAddress1: elements.customAddress1 ? elements.customAddress1.value.trim() : '',
      customAddress2: elements.customAddress2 ? elements.customAddress2.value.trim() : '',
      customLocality: elements.customLocality ? elements.customLocality.value.trim() : '',
      useRandomNames: elements.useRandomNames ? elements.useRandomNames.checked : false,
      useRandomAddresses: elements.useRandomAddresses ? elements.useRandomAddresses.checked : false,
      hardwareAcceleration: elements.hardwareAcceleration ? elements.hardwareAcceleration.checked : (settingsCache.bypasserAdvancedSettings.hardwareAcceleration !== undefined ? settingsCache.bypasserAdvancedSettings.hardwareAcceleration : defaultSettings.hardwareAcceleration),
      reduceAnimations: elements.reduceAnimations ? elements.reduceAnimations.checked : (settingsCache.bypasserAdvancedSettings.reduceAnimations !== undefined ? settingsCache.bypasserAdvancedSettings.reduceAnimations : defaultSettings.reduceAnimations),
      themeColor: elements.themeColorPicker ? elements.themeColorPicker.value : defaultSettings.themeColor,
      telegramEnabled: elements.telegramEnabled ? elements.telegramEnabled.checked : false,
      telegramBotToken: elements.telegramBotToken ? elements.telegramBotToken.value.trim() : '',
      telegramChatId: elements.telegramChatId ? elements.telegramChatId.value.trim() : '',
      autoClickButtons: elements.autoClickButtons ? elements.autoClickButtons.checked : defaultSettings.autoClickButtons,
      autoClickDelay: elements.autoClickDelay ? parseInt(elements.autoClickDelay.value) || defaultSettings.autoClickDelay : defaultSettings.autoClickDelay,
      lastUpdated: Date.now()
    };
    
    // Update cache immediately for instant UI feedback
    settingsCache.bypasserSettings = updatedSettings;
    settingsCache.bypasserAdvancedSettings = advancedSettings;
    
    // Apply theme color immediately (non-blocking UI update)
    if (elements.themeColorPicker) {
      applyThemeColor(advancedSettings.themeColor);
    }

    // Save all settings to storage (no need to read first - we use cache)
    chrome.storage.local.set({ 
      bypasserSettings: updatedSettings,
      bypasserAdvancedSettings: advancedSettings
    }, () => {
      savePending = false;
      
      if (chrome.runtime.lastError) {
        showMessage('Failed to save settings: ' + chrome.runtime.lastError.message, 'error');
      } else {
        showMessage('Settings saved successfully!', 'success');
        
        // Notify background script and content scripts (non-blocking)
        chrome.runtime.sendMessage({
          type: 'SETTINGS_UPDATED',
          settings: updatedSettings,
          advancedSettings: advancedSettings
        }, (response) => {
          // Handle response or errors silently
          if (chrome.runtime.lastError) {
            // Silently ignore common errors (message channel closed, etc.)
            const errorMsg = chrome.runtime.lastError.message;
            if (errorMsg && !errorMsg.includes('message channel closed') && 
                !errorMsg.includes('background page') && 
                !errorMsg.includes('Extension context invalidated')) {
              // Only log non-common errors if needed
            }
          }
        });
        
        // Also broadcast to all tabs to ensure captcha handler gets the update
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            try {
              chrome.tabs.sendMessage(tab.id, {
                type: 'STRIPE_BYPASSER_ADVANCED_SETTINGS',
                settings: advancedSettings
              }).catch(() => {});
            } catch (e) {
              // Ignore errors (e.g., extension pages)
            }
          });
        });
      }
    });
  }
  
  // Save settings to storage (wrapper for compatibility)
  function saveSettings() {
    debouncedSaveSettings(true); // Immediate save when button clicked
  }

  
  // Show notification message
  function showMessage(text, type = 'success') {
    const notification = elements.notification;
    if (!notification) return;
    
    const icon = type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ';
    
    notification.innerHTML = `<span class="notification-icon">${icon}</span><span class="notification-text">${text}</span>`;
    notification.className = `notification notification-${type}`;
    notification.style.display = 'flex';
    notification.classList.remove('show');
    
    // Force reflow
    void notification.offsetWidth;
    
    // Show notification
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    // Hide notification after 3 seconds
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        notification.style.display = 'none';
      }, 300);
    }, 3000);
  }

  // Helper function to update API key field visibility
  function updateApiKeyFieldVisibility() {
    const apiKeySetting = document.getElementById('apiKeySetting');
    if (apiKeySetting && elements.captchaService) {
      if (elements.captchaService.value === 'autoclick') {
        apiKeySetting.style.display = 'none';
      } else {
        apiKeySetting.style.display = 'flex';
      }
    }
  }

  // Event listeners
  elements.saveSettingsBtn.addEventListener('click', saveSettings);
  
  // Autofill specific buttons
  if (elements.saveAutofillSettingsBtn) {
    elements.saveAutofillSettingsBtn.addEventListener('click', () => {
      saveSettings();
      showMessage('Autofill settings saved!', 'success');
    });
  }
  
  if (elements.resetAutofillSettingsBtn) {
    elements.resetAutofillSettingsBtn.addEventListener('click', () => {
      // Reset only autofill custom fields to defaults
      if (elements.autofillDelay) elements.autofillDelay.value = defaultSettings.autofillDelay;
      if (elements.customCardNumber) elements.customCardNumber.value = defaultSettings.customCardNumber;
      if (elements.customCardExpiry) elements.customCardExpiry.value = defaultSettings.customCardExpiry;
      if (elements.customCardCvc) elements.customCardCvc.value = defaultSettings.customCardCvc;
      if (elements.customName) elements.customName.value = defaultSettings.customName;
      if (elements.customAddress1) elements.customAddress1.value = defaultSettings.customAddress1;
      if (elements.customAddress2) elements.customAddress2.value = defaultSettings.customAddress2;
      if (elements.customLocality) elements.customLocality.value = defaultSettings.customLocality;
      if (elements.useRandomNames) elements.useRandomNames.checked = defaultSettings.useRandomNames;
      if (elements.useRandomAddresses) elements.useRandomAddresses.checked = defaultSettings.useRandomAddresses;
      if (elements.telegramEnabled) elements.telegramEnabled.checked = defaultSettings.telegramEnabled;
      if (elements.telegramBotToken) elements.telegramBotToken.value = defaultSettings.telegramBotToken;
      if (elements.telegramChatId) elements.telegramChatId.value = defaultSettings.telegramChatId;
      
      saveSettings();
      showMessage('Autofill settings reset to default!', 'success');
    });
  }
  
  // Auto-save when toggles are changed (debounced for performance, instant UI feedback)
  if (elements.autoCvcToggle) {
    elements.autoCvcToggle.addEventListener('change', () => {
      // Update cache immediately for instant UI feedback
      if (settingsCache.bypasserSettings) {
        settingsCache.bypasserSettings.autoCvc = elements.autoCvcToggle.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.autoScreenshotToggle) {
    elements.autoScreenshotToggle.addEventListener('change', () => {
      if (settingsCache.bypasserSettings) {
        settingsCache.bypasserSettings.autoScreenshot = elements.autoScreenshotToggle.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.hardwareAcceleration) {
    elements.hardwareAcceleration.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.hardwareAcceleration = elements.hardwareAcceleration.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.reduceAnimations) {
    elements.reduceAnimations.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.reduceAnimations = elements.reduceAnimations.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  // elements.autoCaptchaToggle.addEventListener('change', () => {
  //   if (settingsCache.bypasserAdvancedSettings) {
  //     settingsCache.bypasserAdvancedSettings.autoCaptcha = elements.autoCaptchaToggle.checked;
  //   }
  //   debouncedSaveSettings();
  // }, { once: false });
  
  if (elements.autofillToggle) {
    elements.autofillToggle.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.autofill = elements.autofillToggle.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.autofillCardDataToggle) {
    elements.autofillCardDataToggle.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.autofillCardData = elements.autofillCardDataToggle.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.autofillBillingDataToggle) {
    elements.autofillBillingDataToggle.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.autofillBillingData = elements.autofillBillingDataToggle.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  // Auto-save when random autofill toggles are changed (debounced)
  if (elements.useRandomNames) {
    elements.useRandomNames.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.useRandomNames = elements.useRandomNames.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.useRandomAddresses) {
    elements.useRandomAddresses.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.useRandomAddresses = elements.useRandomAddresses.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  // Telegram settings event listeners (debounced)
  if (elements.telegramEnabled) {
    elements.telegramEnabled.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.telegramEnabled = elements.telegramEnabled.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.telegramBotToken) {
    elements.telegramBotToken.addEventListener('input', () => {
      // Update cache immediately, debounce storage save
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.telegramBotToken = elements.telegramBotToken.value.trim();
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.telegramChatId) {
    elements.telegramChatId.addEventListener('input', () => {
      // Update cache immediately, debounce storage save
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.telegramChatId = elements.telegramChatId.value.trim();
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  // Test Telegram connection button
  // Password visibility toggle for Bot Token
  const toggleVisibilityBtn = document.querySelector('.telegram-toggle-visibility');
  if (toggleVisibilityBtn && elements.telegramBotToken) {
    toggleVisibilityBtn.addEventListener('click', () => {
      const input = elements.telegramBotToken;
      const eyeIcon = toggleVisibilityBtn.querySelector('.eye-icon');
      const eyeOffIcon = toggleVisibilityBtn.querySelector('.eye-off-icon');
      
      if (input.type === 'password') {
        input.type = 'text';
        if (eyeIcon) eyeIcon.style.display = 'none';
        if (eyeOffIcon) eyeOffIcon.style.display = 'block';
      } else {
        input.type = 'password';
        if (eyeIcon) eyeIcon.style.display = 'block';
        if (eyeOffIcon) eyeOffIcon.style.display = 'none';
      }
    });
  }
  
  // Auto-clicker settings event listeners
  if (elements.autoClickButtons) {
    elements.autoClickButtons.addEventListener('change', () => {
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.autoClickButtons = elements.autoClickButtons.checked;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.autoClickDelay) {
    elements.autoClickDelay.addEventListener('input', () => {
      // Update cache immediately, debounce storage save
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.autoClickDelay = parseInt(elements.autoClickDelay.value) || defaultSettings.autoClickDelay;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.testTelegramConnection) {
    elements.testTelegramConnection.addEventListener('click', async () => {
      const botToken = elements.telegramBotToken ? elements.telegramBotToken.value.trim() : '';
      const chatId = elements.telegramChatId ? elements.telegramChatId.value.trim() : '';
      
      if (!botToken || !chatId) {
        showMessage('Please enter both Bot Token and Chat ID', 'error');
        return;
      }
      
      const btn = elements.testTelegramConnection;
      btn.disabled = true;
      btn.classList.add('loading');
      const originalContent = btn.innerHTML;
      btn.innerHTML = '<span></span>';
      
      try {
        const TELEGRAM_API_URL = 'https://api.telegram.org/bot';
        const url = `${TELEGRAM_API_URL}${botToken}/sendMessage`;
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            chat_id: parseInt(chatId) || chatId,
            text: '🧪 <b>Test Connection</b>\n\n✅ Telegram notification is working correctly!\n\n📢 Join: t.me/binbhai',
            parse_mode: 'HTML'
          })
        });
        
        const data = await response.json();
        
        if (response.ok && data.ok) {
          showMessage('✅ Connection successful! Check your Telegram for the test message.', 'success');
        } else {
          showMessage(`❌ Connection failed: ${data.description || 'Unknown error'}`, 'error');
        }
      } catch (error) {
        showMessage(`❌ Connection failed: ${error.message}`, 'error');
      } finally {
        btn.disabled = false;
        btn.classList.remove('loading');
        btn.innerHTML = originalContent;
      }
    });
  }
  
  if (elements.captchaService) {
    elements.captchaService.addEventListener('change', () => {
      // Show/hide API key field based on service selection
      updateApiKeyFieldVisibility();
      // Update cache immediately
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.captchaService = elements.captchaService.value;
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  if (elements.captchaApiKey) {
    elements.captchaApiKey.addEventListener('input', () => {
      // Update cache immediately, debounce storage save
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.captchaApiKey = elements.captchaApiKey.value.trim();
      }
      debouncedSaveSettings();
    }, { once: false });
  }
  
  // Theme color picker
  if (elements.themeColorPicker) {
    elements.themeColorPicker.addEventListener('input', (e) => {
      const color = e.target.value;
      // Apply theme immediately (non-blocking UI update)
      applyThemeColor(color);
      // Update cache immediately
      if (settingsCache.bypasserAdvancedSettings) {
        settingsCache.bypasserAdvancedSettings.themeColor = color;
      }
      debouncedSaveSettings();
      
      // Update preset button states
      document.querySelectorAll('.theme-preset-btn').forEach(btn => {
        if (btn.dataset.color === color) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    });
  }
  
  // Reset theme color button
  if (elements.resetThemeColor) {
    elements.resetThemeColor.addEventListener('click', () => {
      const defaultColor = defaultSettings.themeColor;
      if (elements.themeColorPicker) {
        elements.themeColorPicker.value = defaultColor;
        applyThemeColor(defaultColor);
        saveSettings();
        
        // Update preset button states
        document.querySelectorAll('.theme-preset-btn').forEach(btn => {
          if (btn.dataset.color === defaultColor) {
            btn.classList.add('active');
          } else {
            btn.classList.remove('active');
          }
        });
      }
    });
  }
  
  // Preset color buttons
  document.querySelectorAll('.theme-preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const color = btn.dataset.color;
      if (elements.themeColorPicker) {
        elements.themeColorPicker.value = color;
        applyThemeColor(color);
        saveSettings();
        
        // Update all preset button states
        document.querySelectorAll('.theme-preset-btn').forEach(b => {
          if (b === btn) {
            b.classList.add('active');
          } else {
            b.classList.remove('active');
          }
        });
      }
    });
  });
  
  // Initialize API key field visibility on load
  setTimeout(() => {
    if (elements.captchaService && elements.captchaService.value === 'autoclick') {
      const apiKeySetting = document.getElementById('apiKeySetting');
      if (apiKeySetting) {
        apiKeySetting.style.display = 'none';
      }
    }
  }, 100);

  // Format card expiry input (MM/YY)
  if (elements.customCardExpiry) {
    elements.customCardExpiry.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      if (value.length >= 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
      }
      e.target.value = value;
    });
    
    elements.customCardExpiry.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && e.target.value.length === 3) {
        e.target.value = e.target.value.substring(0, 2);
      }
    });
  }
  
  // Format card number input (add spaces every 4 digits, but preserve | format)
  if (elements.customCardNumber) {
    elements.customCardNumber.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '').replace(/\|/g, '|');
      // Only format if it's a plain card number (not the format with |)
      if (!value.includes('|') && value.length > 0) {
        value = value.match(/.{1,4}/g)?.join(' ') || value;
        e.target.value = value;
      }
    });
  }
  
  // Autofill section collapse/expand functionality
  function initAutofillSectionToggle() {
    const autofillToggle = document.getElementById('autofillSectionToggle');
    const autofillContent = document.getElementById('autofillSectionContent');
    const autofillChevron = autofillToggle?.querySelector('.section-chevron');
    
    if (!autofillToggle || !autofillContent) {
      // Retry if elements not found yet
      setTimeout(initAutofillSectionToggle, 100);
      return;
    }
    
    // Load collapsed state from storage (default to collapsed/minimized)
    chrome.storage.local.get(['autofillSectionCollapsed'], (result) => {
      // Default to collapsed (minimized) if not set
      const isCollapsed = result.autofillSectionCollapsed !== false;
      if (isCollapsed) {
        autofillContent.classList.add('collapsed');
        if (autofillChevron) autofillChevron.classList.add('rotated');
      }
      
      // If not set in storage, save the default (collapsed)
      if (result.autofillSectionCollapsed === undefined) {
        chrome.storage.local.set({ autofillSectionCollapsed: true });
      }
    });
    
    // Toggle functionality
    autofillToggle.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isCollapsed = autofillContent.classList.toggle('collapsed');
      if (autofillChevron) {
        if (isCollapsed) {
          autofillChevron.classList.add('rotated');
        } else {
          autofillChevron.classList.remove('rotated');
        }
      }
      
      // Save collapsed state
      chrome.storage.local.set({ autofillSectionCollapsed: isCollapsed });
    });
  }
  
  // Initialize autofill section toggle
  setTimeout(() => {
    initAutofillSectionToggle();
  }, 50);
  
  // Initialize
  loadSettings();
  
  // Real-time updates: Listen for storage changes
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      // Update UI when settings change (from other tabs/pages)
      if (changes.bypasserSettings || changes.bypasserAdvancedSettings) {
        // Debounce to avoid multiple rapid updates
        clearTimeout(window._settingsUpdateTimeout);
        window._settingsUpdateTimeout = setTimeout(() => {
          loadSettings();
          // Only show notification if we didn't just save (to avoid duplicate notifications)
          if (!savePending) {
            const notification = elements.notification;
            if (notification && !notification.classList.contains('show')) {
              showMessage('Settings updated from another tab', 'success');
            }
          }
        }, 100);
      }
    }
  });
  
  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'RELOAD_SETTINGS' || message.type === 'SETTINGS_UPDATED') {
      // Reload settings when notified
      loadSettings();
      sendResponse({ success: true });
      return true;
    }
  });
  
  // Close button handler
  const closeButton = document.getElementById('closeButton');
  if (closeButton) {
    closeButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      // Send message to parent window to close settings overlay (if in iframe)
      if (window.parent !== window) {
        window.parent.postMessage({ type: 'CLOSE_SETTINGS' }, '*');
      } else {
        // Fallback: Use history.back() instead of location.href to prevent reload
        if (window.history.length > 1) {
          window.history.back();
        } else {
          window.location.href = 'options.html';
        }
      }
      return false;
    });
  }
  
  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        // Send message to parent window to close settings overlay (if in iframe)
        if (window.parent !== window) {
          window.parent.postMessage({ type: 'CLOSE_SETTINGS' }, '*');
        } else {
          window.location.href = 'options.html';
        }
      }
    }
  });
  
  // Prevent iframe from reloading - cache it
  const backgroundIframe = document.getElementById('backgroundIframe');
  if (backgroundIframe) {
    // Mark iframe as loaded to prevent reloads
    backgroundIframe.addEventListener('load', () => {
      // Iframe loaded, keep it in memory
      window.__optionsPageLoaded = true;
    });
  }
})();

