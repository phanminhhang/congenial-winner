(() => {
  'use strict';

  const acceptBtn = document.getElementById('acceptBtn');
  if (!acceptBtn) return;

  acceptBtn.addEventListener('click', () => {
    acceptBtn.disabled = true;
    acceptBtn.textContent = 'Saving...';

    chrome.storage.local.set(
      {
        disclaimerAccepted: true,
        disclaimerAcceptedAt: Date.now()
      },
      () => {
        if (chrome.runtime.lastError) {
          acceptBtn.disabled = false;
          acceptBtn.textContent = 'I Understand & Agree';
          return;
        }

        // Send message to parent window to close disclaimer overlay (if in iframe)
        if (window.parent !== window) {
          window.parent.postMessage({ type: 'CLOSE_DISCLAIMER' }, '*');
        } else {
          // Fallback: Navigate to options page (if not in iframe)
          chrome.runtime.openOptionsPage(() => {
            window.close();
          });
        }
      }
    );
  });
})();
